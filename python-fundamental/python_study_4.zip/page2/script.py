# Definisikan class MenuItem
class MenuItem:
    pass