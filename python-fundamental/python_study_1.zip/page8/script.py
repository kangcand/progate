# Tetapkan 'Bob' ke variable my_name 
my_name= "Bob"

# Cetak 'Nama saya Bob' dengan menggabungkan variable my_name dan sebuah string
print("Nama saya "+my_name)