fruits = {'apel': 'apple', 'jeruk': 'orange', 'anggur': 'grape'}

# Dengan loop for, cetak '___ adalah ___ dalam bahasa Inggris'
for fruit in fruits:
    print(fruit+' adalah '+fruits[fruit]+' dalam bahasa Inggris')
