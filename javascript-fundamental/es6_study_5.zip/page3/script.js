// Hapus code di bawah
// Hapus code di atas

// Import constant dog
import dog from "./dogData";
// Export constant dog
export default dog;


dog.info();