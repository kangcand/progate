const animals = ["anjing", "kucing", "domba", "kelinci", "monyet", "harimau", "beruang", "gajah"];

// Gunakan property length untuk mem-print jumlah element di array
console.log(animals.length);

// Gunakan property length untuk mengubah kondisi dibawah
for (let i = 0; i < animals.length; i++) {
  console.log(animals[i]);
}
