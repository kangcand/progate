// Cetak hasil 8 kali 4 di console.
console.log(8*4);

// Cetak hasil 24 bagi 4 di console.
console.log(24 / 4);

// Cetak sisa setelah membagi 7 dengan 2 di console.
console.log(7 % 2);
