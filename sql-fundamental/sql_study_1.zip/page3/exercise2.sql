-- Akses semua kolom dari tabel "purchases" 
-- Akses semua kolom dari tabel "purchases" 
SELECT *
FROM purchases;
