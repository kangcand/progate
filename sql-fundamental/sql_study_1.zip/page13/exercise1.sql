/*
dibawah "FROM purchases" tambahkan code untuk
menampilkan maksimum 5 baris hasil
*/

SELECT *
FROM purchases
LIMIT 5;