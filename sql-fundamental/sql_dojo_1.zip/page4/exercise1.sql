-- dapatkan nama, harga dan laba semua produk
SELECT name, price, price - cost
FROM items;
