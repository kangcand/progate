-- dapatkan setiap nama barang unik (tanpa duplikat)
SELECT DISTINCT(name)
FROM items;
